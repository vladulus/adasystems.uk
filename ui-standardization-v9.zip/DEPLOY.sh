#!/bin/bash
# ADA Systems UI Standardization v8 - Complete Package
# Run from your Laravel root directory

echo "🚀 Starting UI Standardization v8..."

# Backup existing files
echo "📦 Creating backups..."
BACKUP_DIR="backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

cp resources/views/layouts/app.blade.php "$BACKUP_DIR/" 2>/dev/null
cp resources/views/management/index.blade.php "$BACKUP_DIR/management-index.blade.php" 2>/dev/null
cp resources/views/management/devices/index.blade.php "$BACKUP_DIR/devices-index.blade.php" 2>/dev/null
cp resources/views/management/users/index.blade.php "$BACKUP_DIR/users-index.blade.php" 2>/dev/null
cp resources/views/management/vehicles/index.blade.php "$BACKUP_DIR/vehicles-index.blade.php" 2>/dev/null
cp resources/views/management/drivers/index.blade.php "$BACKUP_DIR/drivers-index.blade.php" 2>/dev/null
cp resources/views/pi-dashboard.blade.php "$BACKUP_DIR/" 2>/dev/null
cp resources/views/ada-pi/device-dashboard.blade.php "$BACKUP_DIR/" 2>/dev/null
cp app/Http/Controllers/AutocompleteController.php "$BACKUP_DIR/" 2>/dev/null
cp app/Http/Controllers/ManagementController.php "$BACKUP_DIR/" 2>/dev/null

echo "   Backups saved to $BACKUP_DIR"

# Copy layout
echo "📄 Copying layout..."
cp app.blade.php resources/views/layouts/app.blade.php

# Copy view files
echo "📄 Copying view files..."
cp index.blade.php resources/views/management/index.blade.php
cp devices-index.blade.php resources/views/management/devices/index.blade.php
cp users-index.blade.php resources/views/management/users/index.blade.php
cp vehicles-index.blade.php resources/views/management/vehicles/index.blade.php
cp drivers-index.blade.php resources/views/management/drivers/index.blade.php
cp pi-dashboard.blade.php resources/views/pi-dashboard.blade.php
mkdir -p resources/views/ada-pi
cp ada-pi/device-dashboard.blade.php resources/views/ada-pi/device-dashboard.blade.php

# Copy controllers
echo "📄 Copying controllers..."
cp AutocompleteController.php app/Http/Controllers/AutocompleteController.php
cp ManagementController.php app/Http/Controllers/ManagementController.php

# Clear caches
echo "🧹 Clearing caches..."
php artisan view:clear
php artisan cache:clear
php artisan route:clear

# Cleanup extracted files
echo "🗑️  Cleaning up..."
rm -f app.blade.php
rm -f index.blade.php
rm -f devices-index.blade.php
rm -f users-index.blade.php
rm -f vehicles-index.blade.php
rm -f drivers-index.blade.php
rm -f pi-dashboard.blade.php
rm -rf ada-pi
rm -f AutocompleteController.php
rm -f ManagementController.php
rm -f README.md
rm -f ui-standardization-v8.zip
rm -f DEPLOY.sh

echo ""
echo "✅ Update complete!"
echo ""
echo "Changes applied:"
echo "  • Navbar centered (max-width: 1400px)"
echo "  • Header in card on all pages"
echo "  • Buttons aligned right on all pages"
echo "  • Live autocomplete search"
echo "  • Pi Dashboard standardized"
echo "  • Device Dashboard standardized"
echo "  • Fixed device column search"
